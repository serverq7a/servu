package net.shadowscripts.hiscores;

import net.shadowscripts.mysql.MySQLCallback;
import net.shadowscripts.mysql.MySQLResult;

public class SaveQueryCallback extends MySQLCallback {

	protected String username;
	
	public SaveQueryCallback(String username) {
		this.username = username;
	}
	
	@Override
	public void run(MySQLResult result) {
		System.out.println("[Hiscores] Saved hiscores for " + username);
	}

}
