package net.shadowscripts.hiscores;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

import net.shadowscripts.mysql.MySQL;

public class Hiscores extends Thread {

	private MySQL mysql;

	private String tablePrefix;

	private String queryString;

	private String[] skillNames = { "attack", "defence", "strength",
			"hitpoints", "ranged", "prayer", "magic", "cooking", "woodcutting",
			"fletching", "fishing", "firemaking", "crafting", "smithing",
			"mining", "herblore", "agility", "thieving", "slayer", "farming",
			"runecrafting", "hunter", "construction", "summoning",
			"dungeoneering" };

	private String queryCallbackClass = SaveQueryCallback.class.getName();

	public static void main(String[] args) throws InterruptedException {}

	public Hiscores(String host, String username, String password,
			String database) {
		this(host, username, password, database, "");
	}

	public Hiscores(String host, String username, String password,
			String database, String tablePrefix) {
		int port = 3306;

		String[] hostSplit = host.split(":");

		if (hostSplit.length > 1) {
			port = Integer.parseInt(hostSplit[1]);
		}

		mysql = new MySQL(host, username, password, database, port);
		this.tablePrefix = tablePrefix;
		generateQuery();
	}

	/**
	 * Save a players hiscores to the database
	 * 
	 * @param username
	 *            The username, primary key
	 * @param displayName
	 *            The displayname to show on the hiscores
	 * @param forumUserId
	 *            The forum userid to list this user under, set to 0 for none
	 * @param overallLevel
	 *            The players total level
	 * @param skillsExperience
	 *            An array holding all of the players' experience
	 */
	public void save(final String username, String displayName,
			int forumUserId, int overallLevel, int[] skillsExperience) {
		List<Object> params = new ArrayList<Object>();

		if (skillsExperience.length != skillNames.length) {
			System.out.println("[Hiscores] skillsExperience array length("
					+ skillsExperience.length
					+ ") does not match skill name array length("
					+ skillNames.length + ").");
			return;
		}

		long overallExperience = 0;

		for (int experience : skillsExperience) {
			overallExperience += experience;
		}

		params.add(username);
		params.add(displayName);
		params.add(forumUserId);
		params.add(overallLevel);
		params.add(overallExperience);

		for (int i = 0; i < skillNames.length; i++) {
			params.add(skillsExperience[i]);
		}

		Constructor<?> c;
		SaveQueryCallback callback = null;
		try {
			c = Class.forName(queryCallbackClass).getConstructor(String.class);
			callback = (SaveQueryCallback) c.newInstance(username);
		} catch (Exception e) {
			e.printStackTrace();
		}

		mysql.query(queryString, callback, params);
	}

	/**
	 * Set the skills to save to the database
	 * 
	 * @param skills
	 */
	public void setSkills(String[] skills) {
		this.skillNames = skills;
		generateQuery();
	}

	/**
	 * Set a custom callback that gets ran when the hiscores save for a user.
	 * Class must extend {@link net.shadowscripts.hiscores.SaveQueryCallback}
	 * and override the run
	 * {@link net.shadowscripts.hiscores.SaveQueryCallback#run(net.shadowscripts.mysql.MySQLResult)
	 * method}.
	 * 
	 * @param clazz
	 */
	public void setSaveCallback(String clazz) {
		queryCallbackClass = clazz;
	}

	/**
	 * Generates the query to run when updating players
	 */
	private void generateQuery() {
		StringBuilder query = new StringBuilder("INSERT INTO `" + tablePrefix
				+ "hiscores` (");

		query.append("`server_username`, `server_displayname`, `forum_userid`, `overall_level`, `overall_xp`");

		for (String skill : skillNames) {
			query.append(",`" + skill.toLowerCase() + "`");
		}

		query.append(") VALUES (?,?,?,?,?");

		for (int i = 0; i < skillNames.length; i++) {
			query.append(",?");
		}

		query.append(") ON DUPLICATE KEY UPDATE `server_displayname` = VALUES(`server_displayname`), `forum_userid` = VALUES(`forum_userid`), `overall_level` = VALUES(`overall_level`), `overall_xp` = VALUES(`overall_xp`)");

		for (String skill : skillNames) {
			query.append(",`" + skill.toLowerCase() + "` = VALUES(`"
					+ skill.toLowerCase() + "`)");
		}

		queryString = query.append(";").toString();
	}

}
