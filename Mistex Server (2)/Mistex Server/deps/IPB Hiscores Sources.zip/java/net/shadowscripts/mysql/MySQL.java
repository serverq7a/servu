package net.shadowscripts.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MySQL extends Thread {

	/**
	 * The MySQL Connection
	 */
	private Connection connection = null;

	private String host;
	private String username;
	private String password;
	private String database;
	private int port;
	
	/**
	 * Query queue
	 */
	private List<MySQLQuery> queryQueue = new ArrayList<MySQLQuery>();

	/**
	 * Connect to a MySQL database
	 * 
	 * @param host
	 *            The host of the database
	 * @param username
	 *            Database username
	 * @param password
	 *            User password
	 * @param database
	 *            The database to use
	 */
	public MySQL(String host, String username, String password, String database) {
		this(host, username, password, database, 3306);
	}

	/**
	 * Connect to a MySQL database on a different port
	 * 
	 * @param host
	 *            The host of the database
	 * @param username
	 *            Database username
	 * @param password
	 *            User password
	 * @param database
	 *            The database to use
	 * @param port
	 *            The port to connect to
	 */
	public MySQL(String host, String username, String password, String database, int port) {
		try {
			this.host = host;
			this.username = username;
			this.password = password;
			this.database = database;
			this.port = port;
			
			connection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database, username, password);
			System.out.println("Connected to " + host + ":" + port + ".");
			start();
		} catch (SQLException e) {
			System.err.println("Can not connect to the MySQL Database Server. "
					+ "Please check your configuration.\n\n" + "Hostname: "
					+ host + "\n" + "Username: " + username + "\n\n"
					+ "Error: " + e.getLocalizedMessage());
		}
	}

	/**
	 * Runs all pending queries and makes sure the database is connected.
	 */
	@Override
	public void run() {
		while (true) {
			try {
				List<MySQLQuery> newQueryQueue = new ArrayList<MySQLQuery>();
				
				Iterator<MySQLQuery> it = queryQueue.iterator();

				while (it.hasNext()) {
					MySQLQuery query = it.next();

					boolean executed = query.execute();

					if (!executed && query.getFailures() < 10) {
						newQueryQueue.add(query);
					}
				}
				
				queryQueue.clear();
				queryQueue.addAll(newQueryQueue);
				sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void query(String query) {
		query(query, null);
	}

	public void query(String query, MySQLCallback callback) {
		query(query, callback, (Object) null);
	}
	
	public void query(String query, MySQLCallback callback, Object... params) {		
		MySQLQuery mysqlQuery = new MySQLQuery(this, query, callback, params);
		queryQueue.add(mysqlQuery);
	}
	
	public void query(String query, MySQLCallback callback, List<Object> params) {
		MySQLQuery mysqlQuery = new MySQLQuery(this, query, callback, params.toArray());
		queryQueue.add(mysqlQuery);
	}
	
	public void autoReconnect() {
		System.out.println("Attempting to Reconnect...");
		
		try {
			connection.close();
			connection = null;
		} catch (SQLException e) {
		}
		
		boolean connected = false;
		
		int retiresLeft = 10;
		while (retiresLeft > 0 && !connected) {
			retiresLeft--;
			
			System.out.println("Reconnect Attempt #" + (10 - retiresLeft) + " of " + 10);
			
			try {
				sleep(5000);
				connection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database, username, password);
				connected = true;
			} catch (InterruptedException e) {
				System.out.println("Reconnect canceled");
			} catch (SQLException e) {
				System.out.println("Reconnect error: " + e.getMessage());
			}
		}
	}
	
	/**
	 * Get the database connection
	 * 
	 * @return The connection
	 */
	public Connection getConnection() {
		return connection;
	}

}
