package net.shadowscripts.mysql;

import java.sql.ResultSet;

public class MySQLResult {

	private ResultSet resultSet;
	
	private int rowsChanged = 0;
	
	public MySQLResult(ResultSet resultSet) {
		this.resultSet = resultSet;
	}

	public MySQLResult(int rowsChanged) {
		this.rowsChanged = rowsChanged;
	}
	
	public ResultSet getResultSet() {
		return resultSet;
	}
	
	public int getRowsChanged() {
		return rowsChanged;
	}
	
}
