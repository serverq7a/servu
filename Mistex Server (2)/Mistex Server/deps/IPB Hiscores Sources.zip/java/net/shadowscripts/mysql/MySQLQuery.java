package net.shadowscripts.mysql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLQuery {

	/**
	 * Instance of the database connection
	 */
	private MySQL mysql;

	/**
	 * The query to execute
	 */
	private String query = "";

	/**
	 * The callback to run after execution
	 */
	private MySQLCallback callback;
	
	/**
	 * The total times this query has failed
	 */
	private int failures = 0;

	/**
	 * The params for the query
	 */
	private Object[] params;

	public MySQLQuery(MySQL mysql, String query,
			MySQLCallback callback, Object[] params) {
		this.mysql = mysql;
		this.query = query;
		this.callback = callback;
		this.params = params;
	}

	public boolean execute() {
		checkConnection();

		PreparedStatement statement;

		MySQLResult result = null;

		try {
			statement = mysql.getConnection().prepareStatement(query);

			// Set all of the parameters for this query
			if (params == null) {
				params = new Object[] {};
			}
			
			for (int i = 0; i < params.length; i++) {
				statement.setObject(i + 1, params[i]);
			}

			if (query.toLowerCase().startsWith("select")) {
				result = new MySQLResult(statement.executeQuery());
			} else {
				result = new MySQLResult(statement.executeUpdate());
			}

			if (callback != null) {
				callback.run(result);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			failures++;
			return false;
		} finally {
			if (result != null && result.getResultSet() instanceof ResultSet) {
				try {
					((ResultSet) result.getResultSet()).close();
				} catch (SQLException e) {
				}
			}
		}
		return true;
	}

	@SuppressWarnings("unused")
	private void set(PreparedStatement statement, int paramIndex, Object param)
			throws SQLException {
		if (param instanceof String) {
			statement.setString(paramIndex, (String) param);
		} else if (param instanceof Integer) {
			statement.setInt(paramIndex, (Integer) param);
		} else if (param instanceof Boolean) {
			statement.setBoolean(paramIndex, (Boolean) param);
		} else {
			System.out.println("Unhandled set: " + param.getClass().getName());
			System.exit(0);
		}
	}

	private void checkConnection() {
		Statement statement;
		ResultSet result;
//		boolean autoReconnect = true;
		try {
			statement = mysql.getConnection().createStatement();
			result = statement.executeQuery("SELECT 1;");
			result.close();
		} catch (SQLException e) {
			System.out.println("Database connection lost attempting to reconnect..");
//			if (autoReconnect) {
				mysql.autoReconnect();
//			}
		} catch (NullPointerException e) {
			System.out.println("Database isn't connected.");
			System.exit(0);
		} finally {
			result = null;
		}
	}
	
	public int getFailures() {
		return failures;
	}

}
