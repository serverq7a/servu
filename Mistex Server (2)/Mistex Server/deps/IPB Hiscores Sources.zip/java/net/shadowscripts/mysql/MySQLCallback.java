package net.shadowscripts.mysql;

public abstract class MySQLCallback {

	/**
	 * Something to run after a successful query
	 * 
	 * @param result
	 */
	public abstract void run(MySQLResult result);

}
